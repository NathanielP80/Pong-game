
//This is the main class which creates a frame which then allows you to run the program
public class Main {

    public static void main(String[] args){

        Frame  f = new Frame();
    }

}