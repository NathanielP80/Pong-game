import java.awt.*;
import java.util.*;


public class Ball extends Rectangle {

    Random random;
    int xVelocity;
    int yVelocity;
    int intialSpeed = 2;
    public Ball(int x, int y, int width, int height){
        //This is the constructor for the ball class it sets the movement of the ball
        super(x,y,width,height);
        random = new Random();
        int randomXDirection = random.nextInt(2);
        if(randomXDirection == 0)
            randomXDirection--;
        setXDirection(randomXDirection*intialSpeed);

        int randomYDirection = random.nextInt(2);
        if(randomYDirection == 0)
            randomYDirection--;
        setYDirection(randomYDirection*intialSpeed);

    }
    public void setXDirection(int randomXDirection){
        //This sets the x directions movement
        xVelocity = randomXDirection;
    }
    public void setYDirection(int randomYDirection){
        //This set the y directions movement
        yVelocity = randomYDirection;
    }
    public void move(){
        //This is the move method that sets the x and y to the velocity in the variables above
        x += xVelocity;
        y += yVelocity;
    }
    public void draw(Graphics g){
        //This sets the graphics of the ball making it orange and the placement
        g.setColor(Color.ORANGE);
        g.fillOval(x,y,height,width);
    }
}
