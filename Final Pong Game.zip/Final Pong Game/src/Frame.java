import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;


public class Frame extends JFrame {

    Panel p;

    public Frame(){
        //This is the constructor for the Frame class which creates the window to play the game on
        p = new Panel();
        this.add(p);
        this.setTitle("Pong");
        this.setResizable(false);
        this.setBackground(Color.LIGHT_GRAY);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
}
